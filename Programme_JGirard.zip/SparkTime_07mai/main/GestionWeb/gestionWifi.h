/*
    Nom:

    Description:

    Modification: -
    Création: 29/04/2025
    Auteur: Josée Girard
*/


#ifndef GESTION_WIFI_H
#define GESTION_WIFI_H

void demarrerWifiAP(void);

#endif