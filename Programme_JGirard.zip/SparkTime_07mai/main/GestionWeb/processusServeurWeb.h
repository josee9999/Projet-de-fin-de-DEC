/*
    Nom: 

    Description: 
                 
    Modification: -
    Création: 29/04/2025
    Auteur: Josée Girard   
*/

#ifndef PROCESSUS_SERVEUR_WEB_H
#define PROCESSUS_SERVEUR_WEB_H

void task_serveurWeb(void *pvParameter);

#endif